# Umut AI — Android APK kaynak projesi

Bu paket, Umut AI'nın Android uygulama kabuğu ve kaynak kodudur. **Bu ZIP'in içinde derlenmiş APK dosyası yoktur.** APK, Android derleme araçlarıyla oluşturulmalıdır.

## Telefonda APK oluşturma (bilgisayarsız yol)

1. GitHub hesabınızda yeni ve boş bir repository açın.
2. ZIP'i telefonunuzda açın ve içindeki tüm dosya/klasörleri repository'ye yükleyin. `.github/workflows/build-apk.yml` dosyası da yüklenmiş olmalı.
3. Repository'de **Actions** sekmesini açın. Gerekirse workflow kullanımını etkinleştirin.
4. **Build Umut AI APK** workflow'unu seçip **Run workflow** düğmesine basın.
5. İşlem tamamlanınca ilgili çalıştırmayı açın, **Artifacts** bölümünden `Umut-AI-debug-APK` dosyasını indirin.
6. ZIP artifact'ini açın; içindeki `app-debug.apk` dosyasını telefona indirip açın. Android sorarsa yalnızca güvendiğiniz dosya için bu kaynağa yükleme izni verin.

GitHub arayüzü telefonda biraz uğraştırabilir; dosya yüklerken klasör yapısını ve özellikle `.github/workflows` klasörünü koruyun.

## Önemli

- Bu, imzalanmamış test/debug APK üretir; Play Store için uygun imzalı yayın paketi değildir.
- Web arayüzü APK'nın içine konmuştur. Gerçek AI yanıtları için Ayarlar ekranına OpenAI uyumlu API adresi, model ve API anahtarı girilmesi gerekir. API sağlayıcısının kullanım ücreti olabilir.
- Bu prototip API anahtarını WebView içindeki tarayıcı depolamasında tutar; kişisel test içindir. Başkalarına dağıtmayın. Güvenli yayın sürümünde anahtar sunucu tarafında tutulmalıdır.
- Google arama düğmesi Google'da arama sayfası açar; sonuçları otomatik olarak sohbete getirmez. PDF içeriğini otomatik okuma henüz yoktur.
- Android WebView ve API sağlayıcısının CORS kuralları nedeniyle bazı API bağlantıları doğrudan çalışmayabilir; böyle bir durumda güvenli bir arka uç/proxy gerekir.
- Android mikrofon izinleri ve WebView konuşma tanıma desteği cihaza göre değişebilir; klavye mikrofonu alternatif olabilir.
